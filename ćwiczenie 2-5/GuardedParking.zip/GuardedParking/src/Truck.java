public class Truck extends Car {

    @Override
    public void park() {

    }

    @Override
    public void driveOut() {

    }
}
