public interface Printf {
    public void print();
}
