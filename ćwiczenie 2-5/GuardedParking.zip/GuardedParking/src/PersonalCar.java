public class PersonalCar extends Car {
    @Override
    public void park() {

    }
    @Override
    public void driveOut() {

    }
}
