public class Bus extends Car {

    @Override
    public void driveOut() {

    }

    @Override
    public void park() {

    }
}
